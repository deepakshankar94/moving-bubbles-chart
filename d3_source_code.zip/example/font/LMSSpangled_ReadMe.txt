LMS Star Spangled TTF for PC
by London Stokes

This font is Freeware, in that you can use it free of charge
(non commercial purposes only) without getting permission.

If you distribute this font in any way, this zipfile must be kept
intact, without alterations.  This font, with this read-me file may
be made available for downloading from a website.

This font is upper and lowercase letters and numbers. 

*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*

This font is a tribute to the United States of America and all that she
stands for.  And to the victims and families of the victims of the
terrorist attack on America on 11 September 2001.

I sat and watched the horrible events unfold on TV, comforting friends
who have family in the area while they wait in agony to hear if they 
were okay.  And although I realize this font is but a small tribute, I 
felt that I had to do something, anything to let those who suffer know 
that they are not alone.

*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*

If you like this font, and feel inclined, please email me at:
RioArizona@hotmail.com and let me know.  It's always a wonderful
feeling to know that your fonts are being downloaded and used!  This
and all my other fonts can be downloaded from the "London's Letters"
web site: http://www.geocities.com/rioarizona/Font.htm

Enjoy! 

<<<<<<<< CONDITIONS OF USE >>>>>>>>>

1. This font can be used for personal use only. Businesses or companies
   must gain permission for use. 

2. It can not be included in any compilation CD's, disks or product, 
   either commercial or shareware (unless prior permission granted).
   
3. The zipfile containing the font and this text file must be kept
   intact, without alterations, additions or deletions.

4. This font can be transferred, stored or made available to other
   computers or on the internet/bulletin board as long as no fee or
   charge is requested.

5. No warranty is offered, or understood to have been offered by the
   supplier of this font, and the risk of any losses or damage (personal,
   financial or otherwise) from the use of this font remain with the user.

6. The supplier can not be responsible for any problems that may arise
   by misuse of the font. 

7. The term 'Freeware' shall be taken and understood to mean that you
   can use the font, without restrictions.

